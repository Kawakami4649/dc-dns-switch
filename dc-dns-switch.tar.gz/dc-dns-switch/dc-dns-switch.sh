#!/bin/bash

# TinyBox Network Interface
if [ -f /etc/tinybox/network.conf ]; then
    source /etc/tinybox/network.conf
fi
ETH_IF="${ETH_IF:-eth0}"
WLAN_IF="${WLAN_IF:-wlan0}"

# mesh.conf を読み込み
source /etc/mesh.conf
source /etc/halow_mesh.conf

# MASTER 以外はスキップ
if [ "$NODE_TYPE" != "MASTER" ]; then
    echo "$(date) : NODE_TYPE=$NODE_TYPE → dnsmasq 切替処理をスキップ"
    exit 0
fi

CORE_IP="$CORE_RELAY_IP"
HALOW_RT_IP=$(echo "$CORE_IP" | cut -d'/' -f1)
PING_TARGET="8.8.8.8"
CONF="/etc/dnsmasq.conf"
EXTERNALDNS=",8.8.8.8,8.8.4.4"

# dhcp-option=6 の行から LOCALDNS を抽出
# 例: dhcp-option=6,192.168.10.1 → LOCALDNS=192.168.10.1
LOCALDNS=$(grep "^dhcp-option=6," "$CONF" | head -n 1 | sed -E 's/dhcp-option=6,([^,]+).*/\1/')

if [ -z "$LOCALDNS" ]; then
    echo "ERROR: /etc/dnsmasq.conf に dhcp-option=6 が見つかりません"
    exit 1
fi

# ping でHalow wifi接続されている場合はeth0フラッシュ
if ip a show $ETH_IF | grep -q "inet "; then
  if ping -c 1 -W 1 $HALOW_RT_IP > /dev/null 2>&1; then
    ip addr flush dev $ETH_IF
    echo "$(date) : $ETH_IF の IPv4 を削除しました"
  fi
fi

# ping でオンライン判定
if ping -c 1 -W 1 $PING_TARGET > /dev/null 2>&1; then
    # オンライン
    echo "[DNS] Switching to ONLINE mode"
    # すでに外部DNSが付いていない場合だけ追加
    if ! grep -q "$EXTERNALDNS" "$CONF"; then
        sed -i "s/dhcp-option=6,$LOCALDNS/dhcp-option=6,$LOCALDNS$EXTERNALDNS/" "$CONF"
    # ★ 追加：eth0 の IPv4 を完全削除
#        ip addr flush dev eth0
#        echo "$(date) : eth0 の IPv4 を削除しました"
        systemctl restart dnsmasq
    fi
else
    # オフライン
    echo "[DNS] Switching to OFFLINE mode"
    # 外部DNSが付いている場合だけ削除
    if grep -q "$EXTERNALDNS" "$CONF"; then
      sed -i "s/$EXTERNALDNS//" "$CONF"
    # ★ 追加：eth0 の IPv4 を完全削除
#        ip addr flush dev eth0
#        echo "$(date) : eth0 の IPv4 を削除しました"
        systemctl restart dnsmasq
    fi
fi

