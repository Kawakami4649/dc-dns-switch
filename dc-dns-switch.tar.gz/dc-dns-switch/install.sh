sudo cp --preserve=timestamps dc-dns-switch.sh /usr/local/bin/
sudo cp --preserve=timestamps dc-dns-switch.service /etc/systemd/system/
sudo cp --preserve=timestamps dc-dns-switch.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now dc-dns-switch.timer

#systemctl status dc-dns-switch.timer
#journalctl -u dc-dns-switch.service -f

